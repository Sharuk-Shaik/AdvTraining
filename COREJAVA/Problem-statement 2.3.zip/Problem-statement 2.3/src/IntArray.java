
public class IntArray {

	public static void main(String[] args) {  
        int [] arr = new int [] {3, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0, 0};  
        int sum = 0,sumAll=0,s = arr[0];  
        
        for (int i = 0; i < 15; i++) {  
           sum = sum + arr[i];  
        }
        for (int i = 0; i < arr.length; i++) {  
            sumAll = sumAll + arr[i];  
        }
            for(int i=1; i<arr.length; i++)
            {
                if(s>arr[i])
                    s = arr[i];
            }
         
        double average = sumAll / arr.length;
        

        arr[15]=sum;
        arr[16]= (int) average;
        arr[17]=s; 
        
        for (int i = 0; i < arr.length; i++) {  
        	  System.out.print(arr[i]+"  ");
        	
        }
             
    }  
	
}
