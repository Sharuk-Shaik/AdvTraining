import java.util.Scanner;

public class SplitString {
public static void main(String[] args) {
			
	    Scanner sc = new Scanner(System.in);
		String txt= sc.nextLine();
		String[] w=txt.split("");
		
		for(String w1:w){  
			System.out.println(w1); 
			//System.out.println(" ");
		}
	}

	}


