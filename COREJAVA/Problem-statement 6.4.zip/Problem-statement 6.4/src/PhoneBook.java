
import java.util.HashMap;
import java.util.Scanner;
 
public class PhoneBook {

	public static void main(String[] args) {		
		System.out.println("\n\nWelcome to Phone Book \n\n");
		Scanner s=new Scanner(System.in);		
				System.out.print("[Main Menu]:\n\nOption A: Enter details\nOption B: Search for deatails\nOption C: Quit\n\n");
				String command=s.nextLine().trim();				
				HashMap<String, String > Entries = new HashMap<String, String>();

			   
			   
			
				if (command.equalsIgnoreCase("A")){
					System.out.print("Enter the details in the format: name,phone\n:");
					String newent = s.nextLine();
					String newph = s.nextLine();
					 Entries.put(newent, newph);
					 System.out.println("Entry has been added");
					
 
				}else if (command.equalsIgnoreCase("B")){
					System.out.print("Name you are searching for :\n:");
					
					String sea = s.nextLine();
				     System.out.println(Entries.get(sea));
				     
 
				}else if (command.equalsIgnoreCase("C")){
					System.out.println("Application is quitting....");
					System.exit(0);
				}else{					
					System.out.print("Unknown command ! Try again \n:");
				}
			
		}
	}
	
 
