

	import java.util.Scanner;

	class Rectangle{
	    float Length; 
	    float Width; 
	    float area; 
	    float perimeter;
	    
		
	    public float getLength() {
			return Length;
		}

		public void setLength(int length) {
			Length = length;
		}

		public float getWidth() {
			return Width;
		}

		public void setWidth(int width) {
			Width = width;
		}

		public Rectangle()
	    {
	    	Length = 1;
	    	Width= 1;
	    }

	    void information()  {
	        @SuppressWarnings("resource")
			Scanner in = new Scanner(System.in);
	        System.out.print("Enter length: \n");
	        Length = in.nextFloat();
	        System.out.print("Enter width: \n");
	        Width = in.nextFloat();
	    }
	    
	    void  area()
	    {
	        area = Length * Width;
	       
	    }
	 
	     void  perimeter()
	    {
	    	 perimeter = 2*(Length + Width);
	       
	    }

	    void display() {
	    	if(Length>0.0 && Length<20.0 && Width>0.0 && Width<20.0)
	        {
	        System.out.println("Area of Rectangle = " + area);
	        System.out.println("Parameter of Rectangle = " +perimeter);}
	       
	        
	    else{
	    	System.out.println("Invalid input");
	    }
	    }
	    	

	    public static void main(String args[]) {
	    	
	        Rectangle r1 = new Rectangle();
	        r1.information();
	        r1.area();
	        r1.perimeter();
	        r1.display();
	       
	        Rectangle r2 = new Rectangle();
	        r2.information();
	        r2.area();
	        r2.perimeter();
	        r2.display();
	       
	        Rectangle r3 = new Rectangle();
	        r3.information();
	        r3.area();
	        r3.perimeter();
	        r3.display();
	       
	        Rectangle r4 = new Rectangle();
	        r4.information();
	        r4.area();
	        r4.perimeter();
	        r4.display();
	       
	        Rectangle r5 = new Rectangle();
	        r5.information();
	        r5.area();
	        r5.perimeter();
	        r5.display();
	    	
	    }
	}


