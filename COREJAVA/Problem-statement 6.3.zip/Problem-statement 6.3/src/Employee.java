public class Employee {
	 private int employeeNo;
	 private String employeeName, address;
	 public Employee (int empid, String ename, String address) {
		 super();
		 this.employeeNo=empid;
		 this.employeeName=ename;
		 this.address=address;
		 }
	 public int getEmpid() {
		 return employeeNo;
	 }
	 public void setEmpid(int empid) {
		 this.employeeNo=empid;
	 }
	 public String getEname() {
		 return employeeName;
	 }
	 public void setEname(String ename) {
		 this.employeeName=ename;
	 }
	 public String getAddress() {
		 return address;
	 }
	 public void setAddres(String address) {
		 this.address=address;
	 }
	}