import java.util.HashSet;
import java.util.Scanner;
 
class ElementFrequency
{
	public static void main(String[] args){
		Scanner s = new Scanner(System.in);

	    int[] a;
	    System.out.println("Enter the length of the array");
        int n = s.nextInt();
        a = new int[n];
        System.out.println("Enter the array: ");
        
        for(int i=0;i<n;i++){
         a[i] = s.nextInt();
        }
	    HashSet<Integer> nub = new HashSet<Integer>();

	  
	    for(int i=0;i<a.length;i++){
	        
	    	nub.add(a[i]);
	    }
	    
	    System.out.println("Given array is: "+nub);


	    for(int set : nub){
	        int count = 0;
	        for(int j=0;j<a.length;j++){

	            if(set==a[j]){
	                count++;
	            }
	        }
	        System.out.println(set+" occurs "+count+" times");
	    }
	  }
}