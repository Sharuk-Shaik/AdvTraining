import java.util.Scanner;

public class Fibonacci {
	  public static void main(String[] args) {

		     Scanner input = new Scanner(System.in);
		    int i = 1, n = 13,first,second;
			System.out.println("Enter the two values:" );
		    first = input.nextInt();
		    second= input.nextInt();
		    System.out.println("The series is: \n");

		    while (i <= n) {
			      System.out.print(first + ", ");

			      int next = first + second;
			      first = second;
			      second = next;
		      i++;
		    }
		  }
}
