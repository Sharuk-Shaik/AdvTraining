
public class StringDemo{
public static void main(String[] args) {
			
		
		String str= "JAVA is Simple";
		
		System.out.println(str.toUpperCase());
		
		System.out.println(str.toLowerCase()); 
		
		
		String[] words=str.split("\\s");	
		for(String w:words){  
			System.out.print(w.charAt(0)); 
			System.out.print(" ");
		}
		System.out.println(" ");
		
			
			  int left = 0, right = words.length - 1;
			  while (left <= right) {
			    String temp = words[left];
			    words[left] = words[right];
			    words[right] = temp;
			    left += 1;
			    right -= 1;
			  }
			  String ans = String.join(" ", words);
			System.out.println(ans);
		
		
		reverseEachWord(str);
		
		System.out.println("Total length is: "+str.replace(" ", "").length());
}

		private static String reverseEachWord(String str) {

	
	        String[] words = str.split(" ");

	        String reverseStr = "";

	
	        for (String word: words) {
	            
	            reverseStr = reverseStr + reverseWithStringConcat(word) + " ";
	        }

	        display(str, reverseStr);
	        return reverseStr;
	    }

	    private static final void display(String original, String reverse) {
	     
	        System.out.println(reverse);
	       
	    }
	    private static final String reverseWithStringConcat(String string) {
	        String reverseWord = "";
	        for (int i = (string.length() - 1); i >= 0; i--) {
	            reverseWord = reverseWord + string.charAt(i);
	        }
	        return reverseWord;
	    }
}
